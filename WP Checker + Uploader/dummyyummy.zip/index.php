<?php

    /*
    Plugin Name: Wordpress Uploader
    Plugin URI: https://t.me/exploi7
    Description: WordPress Plugin.
    Version: 1.3.3.7
    Author URI: https://t.me/exploi7
    */

?>
